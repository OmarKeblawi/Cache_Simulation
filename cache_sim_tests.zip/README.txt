Cache Simulator Test Suite
==========================

Requirements
------------
- Python 3.10+
- cache_sim.py (your implementation)

How to run
----------
1. Place this folder anywhere on your machine.

2. Run from inside the folder:

   python3.10 run_tests.py

   By default, run_tests.py looks for cache_sim.py at ../hw1/cache_sim.py
   (i.e. one level up, inside an "hw1" folder).

   If your cache_sim.py is elsewhere, point to it with --sim:

   python3.10 run_tests.py --sim /path/to/cache_sim.py

3. Open report.html (generated in this folder) in any browser to see
   the full results — passed, failed, and mismatches highlighted.
