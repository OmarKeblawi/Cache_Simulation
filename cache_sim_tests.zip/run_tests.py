"""
Test runner for cache_sim.py.
Usage: python3 run_tests.py [--sim PATH]
Generates report.html in the tests directory.
"""

import argparse
import os
import subprocess
import sys
import tempfile
from datetime import datetime

TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
CASES_DIR = os.path.join(TESTS_DIR, "cases")
DEFAULT_SIM = os.path.join(TESTS_DIR, "..", "hw1", "cache_sim.py")


def run_test(sim_path, case_dir):
    config = os.path.join(case_dir, "config.txt")
    trace = os.path.join(case_dir, "trace.txt")
    expected_path = os.path.join(case_dir, "expected.txt")

    with open(expected_path) as f:
        expected = f.read().strip()

    with tempfile.NamedTemporaryFile(mode="r", suffix=".txt", delete=False) as tmp:
        out_path = tmp.name

    try:
        result = subprocess.run(
            ["python3.10", sim_path, config, trace, out_path],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode != 0:
            return {"status": "ERROR", "expected": expected,
                    "actual": "", "stderr": result.stderr.strip()}

        with open(out_path) as f:
            actual = f.read().strip()
    except subprocess.TimeoutExpired:
        return {"status": "TIMEOUT", "expected": expected, "actual": "", "stderr": ""}
    finally:
        if os.path.exists(out_path):
            os.unlink(out_path)

    passed = actual == expected
    return {
        "status": "PASS" if passed else "FAIL",
        "expected": expected,
        "actual": actual,
        "stderr": result.stderr.strip(),
    }


def diff_lines(expected, actual):
    exp_lines = expected.splitlines()
    act_lines = actual.splitlines()
    rows = []
    max_len = max(len(exp_lines), len(act_lines))
    for i in range(max_len):
        e = exp_lines[i] if i < len(exp_lines) else "<missing>"
        a = act_lines[i] if i < len(act_lines) else "<missing>"
        match = e == a
        rows.append((i + 1, e, a, match))
    return rows


def build_html(results):
    total = len(results)
    passed = sum(1 for r in results if r["result"]["status"] == "PASS")
    failed = total - passed
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def status_badge(status):
        if status == "PASS":
            return '<span class="badge pass">PASS</span>'
        elif status == "FAIL":
            return '<span class="badge fail">FAIL</span>'
        elif status == "TIMEOUT":
            return '<span class="badge timeout">TIMEOUT</span>'
        return '<span class="badge error">ERROR</span>'

    rows_html = ""
    for idx, r in enumerate(results):
        name = r["name"]
        res = r["result"]
        status = res["status"]
        badge = status_badge(status)

        config_path = os.path.join(CASES_DIR, name, "config.txt")
        trace_path  = os.path.join(CASES_DIR, name, "trace.txt")
        with open(config_path) as f:
            config_txt = f.read().strip()
        with open(trace_path) as f:
            trace_txt = f.read().strip()

        actual_txt = res["actual"] if res["actual"] else ""
        expected_txt = res["expected"]

        # Build diff block for FAIL
        mismatch_html = ""
        if status == "FAIL":
            diff = diff_lines(expected_txt, actual_txt)
            diff_rows = "".join(
                f'<tr class="{"match" if m else "mismatch"}">'
                f'<td>{ln}</td><td>{e}</td><td>{a}</td></tr>'
                for ln, e, a, m in diff
            )
            mismatch_html = f"""
            <div class="section-label">Mismatch</div>
            <div class="diff-block">
              <div class="diff-header">
                <span>Line</span><span>Expected</span><span>Got</span>
              </div>
              <table class="diff-table"><tbody>{diff_rows}</tbody></table>
            </div>"""
        elif status in ("ERROR", "TIMEOUT") and res.get("stderr"):
            mismatch_html = f"""
            <div class="section-label">Error</div>
            <div class="diff-block error-block"><pre>{res["stderr"]}</pre></div>"""

        rows_html += f"""
        <tr class="test-row {status.lower()}" onclick="toggleDetail('d{idx}')">
          <td class="idx">{idx+1}</td>
          <td class="name">{name}</td>
          <td class="cfg"><code>{config_txt}</code></td>
          <td>{badge}</td>
        </tr>
        <tr class="detail-row" id="d{idx}">
          <td colspan="4">
            <div class="detail-inner">
              <div class="panels">
                <div class="panel">
                  <div class="section-label">Config</div>
                  <pre class="code-block">{config_txt}</pre>
                </div>
                <div class="panel">
                  <div class="section-label">Trace (input)</div>
                  <pre class="code-block">{trace_txt}</pre>
                </div>
                <div class="panel">
                  <div class="section-label">Expected output</div>
                  <pre class="code-block">{expected_txt}</pre>
                </div>
                <div class="panel">
                  <div class="section-label">Actual output</div>
                  <pre class="code-block {'empty' if not actual_txt else ''}">{actual_txt if actual_txt else '(empty)'}</pre>
                </div>
              </div>
              {mismatch_html if mismatch_html else '<span class="ok-msg">All lines match.</span>'}
            </div>
          </td>
        </tr>"""

    pass_pct = round(passed / total * 100) if total else 0

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Cache Sim — Test Report</title>
<link rel="preconnect" href="https://fonts.googleapis.com"/>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
<link href="https://fonts.googleapis.com/css2?family=Fira+Code:wght@400;500;600;700&family=Fira+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>
<style>
  *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}

  :root {{
    --bg:       #0F172A;
    --surface:  #1E293B;
    --surface2: #334155;
    --border:   #475569;
    --text:     #F8FAFC;
    --muted:    #94A3B8;
    --pass:     #22C55E;
    --fail:     #EF4444;
    --warn:     #F59E0B;
    --info:     #38BDF8;
    --radius:   8px;
  }}

  body {{
    background: var(--bg);
    color: var(--text);
    font-family: 'Fira Sans', sans-serif;
    font-size: 15px;
    line-height: 1.6;
    min-height: 100vh;
  }}

  /* ── Header ── */
  .header {{
    background: linear-gradient(135deg, #1E293B 0%, #0F172A 100%);
    border-bottom: 2px solid var(--surface2);
    padding: 36px 48px 28px;
  }}
  .header h1 {{
    font-family: 'Fira Code', monospace;
    font-size: 28px;
    font-weight: 700;
    color: var(--text);
    letter-spacing: -0.5px;
  }}
  .header h1 span {{ color: var(--pass); }}
  .subtitle {{
    color: var(--muted);
    font-size: 13px;
    margin-top: 4px;
    font-family: 'Fira Code', monospace;
  }}

  /* ── Stats bar ── */
  .stats {{
    display: flex;
    gap: 20px;
    padding: 24px 48px;
    border-bottom: 1px solid var(--surface2);
    flex-wrap: wrap;
  }}
  .stat-card {{
    background: var(--surface);
    border: 1px solid var(--surface2);
    border-radius: var(--radius);
    padding: 18px 28px;
    min-width: 140px;
    flex: 1;
    max-width: 200px;
  }}
  .stat-card .label {{
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: var(--muted);
    font-weight: 600;
    margin-bottom: 6px;
  }}
  .stat-card .value {{
    font-family: 'Fira Code', monospace;
    font-size: 32px;
    font-weight: 700;
    line-height: 1;
  }}
  .stat-card.total  .value {{ color: var(--info); }}
  .stat-card.passed .value {{ color: var(--pass); }}
  .stat-card.failed .value {{ color: var(--fail); }}
  .stat-card.pct    .value {{ color: {'var(--pass)' if pass_pct == 100 else 'var(--warn)'}; }}

  /* ── Progress bar ── */
  .progress-wrap {{
    padding: 0 48px 24px;
  }}
  .progress-bar {{
    background: var(--surface2);
    border-radius: 99px;
    height: 8px;
    overflow: hidden;
    margin-top: 12px;
  }}
  .progress-fill {{
    height: 100%;
    width: {pass_pct}%;
    background: linear-gradient(90deg, var(--pass) 0%, #16A34A 100%);
    border-radius: 99px;
    transition: width 1s ease;
  }}
  .progress-label {{
    font-size: 12px;
    color: var(--muted);
    font-family: 'Fira Code', monospace;
  }}

  /* ── Filters ── */
  .filters {{
    padding: 16px 48px;
    display: flex;
    gap: 10px;
    border-bottom: 1px solid var(--surface2);
  }}
  .filter-btn {{
    background: var(--surface);
    border: 1px solid var(--surface2);
    color: var(--text);
    padding: 6px 16px;
    border-radius: 99px;
    font-size: 13px;
    cursor: pointer;
    transition: all 200ms ease;
    font-family: 'Fira Sans', sans-serif;
  }}
  .filter-btn:hover, .filter-btn.active {{
    border-color: var(--info);
    color: var(--info);
    background: rgba(56,189,248,0.08);
  }}
  .filter-btn.pass-btn:hover, .filter-btn.pass-btn.active {{
    border-color: var(--pass); color: var(--pass); background: rgba(34,197,94,0.08);
  }}
  .filter-btn.fail-btn:hover, .filter-btn.fail-btn.active {{
    border-color: var(--fail); color: var(--fail); background: rgba(239,68,68,0.08);
  }}
  .search-box {{
    margin-left: auto;
    background: var(--surface);
    border: 1px solid var(--surface2);
    color: var(--text);
    padding: 6px 16px;
    border-radius: 99px;
    font-size: 13px;
    font-family: 'Fira Code', monospace;
    outline: none;
    width: 220px;
    transition: border-color 200ms;
  }}
  .search-box:focus {{ border-color: var(--info); }}

  /* ── Table ── */
  .table-wrap {{
    padding: 24px 48px 48px;
  }}
  table {{ width: 100%; border-collapse: collapse; }}
  thead th {{
    text-align: left;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: var(--muted);
    padding: 10px 14px;
    border-bottom: 1px solid var(--surface2);
    font-weight: 600;
  }}
  .test-row {{
    cursor: pointer;
    transition: background 150ms;
    border-bottom: 1px solid rgba(71,85,105,0.4);
  }}
  .test-row:hover {{ background: rgba(255,255,255,0.03); }}
  .test-row td {{ padding: 12px 14px; }}
  .test-row .idx {{ color: var(--muted); font-family: 'Fira Code', monospace; font-size: 12px; width: 40px; }}
  .test-row .name {{ font-family: 'Fira Code', monospace; font-size: 13px; font-weight: 500; }}
  .test-row .cfg {{ font-size: 12px; color: var(--muted); }}
  .test-row .cfg code {{ font-family: 'Fira Code', monospace; }}

  /* ── Badges ── */
  .badge {{
    display: inline-block;
    padding: 3px 10px;
    border-radius: 99px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.5px;
    font-family: 'Fira Code', monospace;
  }}
  .badge.pass    {{ background: rgba(34,197,94,0.15);  color: var(--pass); border: 1px solid rgba(34,197,94,0.3); }}
  .badge.fail    {{ background: rgba(239,68,68,0.15);  color: var(--fail); border: 1px solid rgba(239,68,68,0.3); }}
  .badge.timeout {{ background: rgba(245,158,11,0.15); color: var(--warn); border: 1px solid rgba(245,158,11,0.3); }}
  .badge.error   {{ background: rgba(148,163,184,0.15);color: var(--muted);border: 1px solid var(--surface2); }}

  /* ── Detail row ── */
  .detail-row {{ display: none; }}
  .detail-row.open {{ display: table-row; }}
  .detail-inner {{
    padding: 16px 14px;
    background: rgba(15,23,42,0.6);
    border-bottom: 1px solid var(--surface2);
  }}
  .ok-msg {{ color: var(--pass); font-size: 13px; font-family: 'Fira Code', monospace; }}

  /* ── Panels ── */
  .panels {{
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 12px;
    margin-bottom: 16px;
  }}
  .panel {{ display: flex; flex-direction: column; gap: 6px; }}
  .section-label {{
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: var(--muted);
    font-weight: 600;
    margin-bottom: 2px;
  }}
  .code-block {{
    background: var(--bg);
    border: 1px solid var(--surface2);
    border-radius: var(--radius);
    padding: 10px 12px;
    font-family: 'Fira Code', monospace;
    font-size: 12px;
    color: var(--text);
    white-space: pre-wrap;
    word-break: break-all;
    flex: 1;
    min-height: 60px;
  }}
  .code-block.empty {{ color: var(--muted); font-style: italic; }}

  /* ── Diff ── */
  .diff-block {{
    border: 1px solid var(--surface2);
    border-radius: var(--radius);
    overflow: hidden;
    font-family: 'Fira Code', monospace;
    font-size: 12px;
  }}
  .diff-header {{
    display: grid;
    grid-template-columns: 50px 1fr 1fr;
    background: var(--surface2);
    padding: 8px 12px;
    font-size: 11px;
    color: var(--muted);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    font-weight: 600;
  }}
  .diff-table {{ width: 100%; border-collapse: collapse; }}
  .diff-table tr td {{ padding: 5px 12px; border-bottom: 1px solid rgba(71,85,105,0.2); }}
  .diff-table tr td:first-child {{ width: 50px; color: var(--muted); }}
  .diff-table tr.mismatch td {{ background: rgba(239,68,68,0.07); }}
  .diff-table tr.mismatch td:nth-child(2) {{ color: var(--pass); }}
  .diff-table tr.mismatch td:nth-child(3) {{ color: var(--fail); }}
  .error-block pre {{ color: var(--fail); font-size: 12px; padding: 12px; white-space: pre-wrap; }}

  /* ── Footer ── */
  .footer {{
    text-align: center;
    padding: 24px;
    color: var(--muted);
    font-size: 12px;
    border-top: 1px solid var(--surface2);
    font-family: 'Fira Code', monospace;
  }}

  @media (max-width: 768px) {{
    .header, .stats, .filters, .table-wrap, .progress-wrap {{ padding-left: 16px; padding-right: 16px; }}
    .stat-card {{ max-width: 100%; }}
  }}
</style>
</head>
<body>

<div class="header">
  <h1>cache_sim.<span>py</span> — Test Report</h1>
  <div class="subtitle">Generated {now} &nbsp;|&nbsp; {total} test cases</div>
</div>

<div class="stats">
  <div class="stat-card total">
    <div class="label">Total</div>
    <div class="value">{total}</div>
  </div>
  <div class="stat-card passed">
    <div class="label">Passed</div>
    <div class="value">{passed}</div>
  </div>
  <div class="stat-card failed">
    <div class="label">Failed</div>
    <div class="value">{failed}</div>
  </div>
  <div class="stat-card pct">
    <div class="label">Pass Rate</div>
    <div class="value">{pass_pct}%</div>
  </div>
</div>

<div class="progress-wrap">
  <div class="progress-label">{passed} / {total} passing</div>
  <div class="progress-bar"><div class="progress-fill"></div></div>
</div>

<div class="filters">
  <button class="filter-btn active" onclick="filterTests('all', this)">All</button>
  <button class="filter-btn pass-btn" onclick="filterTests('pass', this)">Passed</button>
  <button class="filter-btn fail-btn" onclick="filterTests('fail', this)">Failed</button>
  <input class="search-box" type="text" placeholder="Search test name..." oninput="searchTests(this.value)"/>
</div>

<div class="table-wrap">
  <table id="test-table">
    <thead>
      <tr>
        <th>#</th>
        <th>Test Name</th>
        <th>Config</th>
        <th>Status</th>
      </tr>
    </thead>
    <tbody id="test-body">
      {rows_html}
    </tbody>
  </table>
</div>

<div class="footer">cache_sim.py test harness &mdash; Computer Organization HW1</div>

<script>
  function toggleDetail(id) {{
    const el = document.getElementById(id);
    el.classList.toggle('open');
  }}

  function filterTests(type, btn) {{
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('.test-row').forEach(row => {{
      const show = type === 'all' || row.classList.contains(type);
      const detailId = row.nextElementSibling.id;
      row.style.display = show ? '' : 'none';
      row.nextElementSibling.style.display = show ? '' : 'none';
      if (!show) row.nextElementSibling.classList.remove('open');
    }});
  }}

  function searchTests(query) {{
    const q = query.toLowerCase();
    document.querySelectorAll('.test-row').forEach(row => {{
      const name = row.querySelector('.name').textContent.toLowerCase();
      const show = name.includes(q);
      row.style.display = show ? '' : 'none';
      row.nextElementSibling.style.display = show ? '' : 'none';
      if (!show) row.nextElementSibling.classList.remove('open');
    }});
  }}

  // Auto-expand failed tests
  document.querySelectorAll('.test-row.fail, .test-row.error, .test-row.timeout').forEach(row => {{
    row.nextElementSibling.classList.add('open');
  }});
</script>
</body>
</html>"""


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sim", default=DEFAULT_SIM, help="Path to cache_sim.py")
    args = parser.parse_args()

    sim = os.path.abspath(args.sim)
    if not os.path.exists(sim):
        print(f"Simulator not found: {sim}")
        sys.exit(1)

    cases = sorted(os.listdir(CASES_DIR))
    results = []
    for name in cases:
        case_dir = os.path.join(CASES_DIR, name)
        if not os.path.isdir(case_dir):
            continue
        result = run_test(sim, case_dir)
        status = result["status"]
        icon = "✓" if status == "PASS" else "✗"
        print(f"  [{icon}] {name:<45} {status}")
        results.append({"name": name, "result": result})

    passed = sum(1 for r in results if r["result"]["status"] == "PASS")
    total = len(results)
    print(f"\n{'─'*55}")
    print(f"  {passed}/{total} passed ({round(passed/total*100)}%)")

    report_path = os.path.join(TESTS_DIR, "report.html")
    html = build_html(results)
    with open(report_path, "w") as f:
        f.write(html)
    print(f"  Report: {report_path}")


if __name__ == "__main__":
    main()
